#include <iostream>
using namespace std;
#include<cmath>

int main()
{   
    int n;
    cin>>n;
    int x;
    int y;
    x = (int)pow(n,2);
    y = (int)pow(n,3);
    cout << x << endl;
    cout << y;
    return 0;
}
